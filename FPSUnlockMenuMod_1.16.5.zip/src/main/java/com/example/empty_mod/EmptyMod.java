package com.example.empty_mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

import com.mojang.blaze3d.systems.RenderSystem;

@Mod("empty_mod")
public class EmptyMod {

    public EmptyMod() {
        System.out.println("FPS Unlock Mod Loaded!");
    }

    @SubscribeEvent
    public static void onKeyInput(InputEvent.KeyInputEvent event) {
        if (event.getAction() == GLFW.GLFW_PRESS) {
            if (event.getKey() == GLFW.GLFW_KEY_F) { // 'F' tuşuna basıldığında menü aç
                Minecraft.getInstance().setScreen(new FPSMenuScreen());
            }
        }
    }

    public static class FPSMenuScreen extends Screen {
        private TextFieldWidget fpsInput;

        protected FPSMenuScreen() {
            super(new StringTextComponent("Set FPS Limit"));
        }

        @Override
        protected void init() {
            this.fpsInput = new TextFieldWidget(this.font, this.width / 2 - 50, this.height / 2 - 10, 100, 20, new StringTextComponent("Enter FPS"));
            this.children.add(fpsInput);
        }

        @Override
        public void render(int mouseX, int mouseY, float partialTicks) {
            this.renderBackground();
            drawCenteredString(this.font, "Enter FPS:", this.width / 2, this.height / 2 - 30, 0xFFFFFF);
            fpsInput.render(mouseX, mouseY, partialTicks);
            super.render(mouseX, mouseY, partialTicks);
        }

        @Override
        public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
            if (keyCode == GLFW.GLFW_KEY_ENTER) { // Enter'a basılınca FPS'yi güncelle
                try {
                    int customFPS = Integer.parseInt(fpsInput.getValue());
                    if (customFPS > 0) {
                        RenderSystem.limitDisplayFPS(customFPS);
                        System.out.println("FPS set to: " + customFPS);
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid FPS value!");
                }
                Minecraft.getInstance().setScreen(null); // Menüden çık
                return true;
            }
            return super.keyPressed(keyCode, scanCode, modifiers);
        }
    }
}
